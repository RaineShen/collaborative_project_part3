        # try:
        #     if self.gender!="female" or self.gender!="male":
        #         raise ValueError("plase enter your gender, male or female")
        # except ValueError as ex:
        #     print("Message:", ex)